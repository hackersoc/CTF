<?php
$_ = "CTF{ivehadenoughofyour1337games}";
